var searchData=
[
  ['swapsize',['swapSize',['../classSteinberg_1_1Buffer.html#a24e80486061f2d500092ee60eb3a21a5',1,'Steinberg::Buffer']]]
];
