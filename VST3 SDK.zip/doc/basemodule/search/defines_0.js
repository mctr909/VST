var searchData=
[
  ['_5fmeta_5fclass',['_META_CLASS',['../classfactory_8h.html#a46dabd263537e5305c29e252e9d4e0df',1,'classfactory.h']]],
  ['_5fmeta_5fclass_5fiface',['_META_CLASS_IFACE',['../classfactory_8h.html#acc4233582b4e6b60c26daffd4e9d3573',1,'classfactory.h']]]
];
